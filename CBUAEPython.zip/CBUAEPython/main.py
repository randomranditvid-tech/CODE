import os
import sys
import pandas as pd
from openpyxl import load_workbook

# =========================================================
# USAGE
# =========================================================
#
# python vuln_updater.py <input_folder> <output_folder> <mapping_csv>
#
# Example:
#
# python vuln_updater.py "C:\input" "C:\output" "C:\mapping.csv"
#
# =========================================================

if len(sys.argv) != 4:

    print("\nUsage:")
    print(
        'python vuln_updater.py <input_folder> <output_folder> <mapping_csv>'
    )

    sys.exit(1)

INPUT_FOLDER = sys.argv[1]
OUTPUT_FOLDER = sys.argv[2]
MAPPING_CSV = sys.argv[3]

TARGET_SHEET = "Vulnerability Details"

# =========================================================
# VALIDATE PATHS
# =========================================================

if not os.path.exists(INPUT_FOLDER):

    print(f"[ERROR] Input folder not found: {INPUT_FOLDER}")
    sys.exit(1)

if not os.path.exists(MAPPING_CSV):

    print(f"[ERROR] Mapping CSV not found: {MAPPING_CSV}")
    sys.exit(1)

os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# =========================================================
# LOAD MAPPING CSV
# =========================================================

print("[+] Loading mapping CSV...")

mapping_df = pd.read_csv(MAPPING_CSV)

mapping_df["Old Title"] = (
    mapping_df["Old Title"]
    .astype(str)
    .str.strip()
    .str.lower()
)

mapping_dict = {}

for _, row in mapping_df.iterrows():

    mapping_dict[row["Old Title"]] = {
        "New Title": row["New Title"],
        "Risk Level": row["Risk Level"],
        "CVSS Score v 4.0": row["CVSS Score v 4.0"],
        "DREAD Risk Score": row["DREAD Risk Score"],
        "Abstract": row["Abstract"],
        "Impact": row["Impact"],
        "Recommendation": row["Recommendation"]
    }

print(f"[+] Loaded {len(mapping_dict)} mappings")

# =========================================================
# PROCESS FILES
# =========================================================

excel_files = [
    f for f in os.listdir(INPUT_FOLDER)
    if f.lower().endswith(".xlsx")
]

print(f"[+] Found {len(excel_files)} Excel files")

for file_name in excel_files:

    input_file = os.path.join(INPUT_FOLDER, file_name)
    output_file = os.path.join(OUTPUT_FOLDER, file_name)

    print(f"\n=================================================")
    print(f"[+] Processing: {file_name}")

    try:

        wb = load_workbook(input_file)

        # =================================================
        # CHECK SHEET
        # =================================================

        if TARGET_SHEET not in wb.sheetnames:

            print(f"[-] Sheet not found: {TARGET_SHEET}")
            continue

        ws = wb[TARGET_SHEET]

        # =================================================
        # FIND HEADER ROW
        # =================================================

        headers = {}
        header_row = None

        for row in ws.iter_rows(min_row=1, max_row=20):

            for cell in row:

                if cell.value:

                    value = str(cell.value).strip()

                    if value.lower() == "vulnerability title":

                        header_row = cell.row
                        break

            if header_row:
                break

        if not header_row:

            print("[-] Could not find 'Vulnerability Title'")
            continue

        # =================================================
        # MAP HEADERS
        # =================================================

        for cell in ws[header_row]:

            if cell.value:

                headers[
                    str(cell.value).strip()
                ] = cell.column

        # =================================================
        # REQUIRED COLUMNS
        # =================================================

        required_columns = [
            "Vulnerability Title",
            "Risk Level",
            "CVSS Score v 4.0",
            "DREAD Risk Score",
            "Abstract",
            "Impact",
            "Remediation recommendation"
        ]

        last_col = ws.max_column

        for col_name in required_columns:

            if col_name not in headers:

                last_col += 1

                ws.cell(
                    row=header_row,
                    column=last_col
                ).value = col_name

                headers[col_name] = last_col

                print(f"[+] Added column: {col_name}")

        # =================================================
        # UPDATE ROWS
        # =================================================

        title_col = headers["Vulnerability Title"]

        updated_count = 0

        for row_num in range(header_row + 1, ws.max_row + 1):

            cell_value = ws.cell(
                row=row_num,
                column=title_col
            ).value

            if not cell_value:
                continue

            original_title = str(cell_value).strip()
            lookup_title = original_title.lower()

            if lookup_title in mapping_dict:

                vuln_data = mapping_dict[lookup_title]

                # =================================================
                # REPLACE TITLE
                # =================================================

                ws.cell(
                    row=row_num,
                    column=title_col
                ).value = vuln_data["New Title"]

                # =================================================
                # UPDATE VALUES
                # =================================================

                ws.cell(
                    row=row_num,
                    column=headers["Risk Level"]
                ).value = vuln_data["Risk Level"]

                ws.cell(
                    row=row_num,
                    column=headers["CVSS Score v 4.0"]
                ).value = vuln_data["CVSS Score v 4.0"]

                ws.cell(
                    row=row_num,
                    column=headers["DREAD Risk Score"]
                ).value = vuln_data["DREAD Risk Score"]

                ws.cell(
                    row=row_num,
                    column=headers["Abstract"]
                ).value = vuln_data["Abstract"]

                ws.cell(
                    row=row_num,
                    column=headers["Impact"]
                ).value = vuln_data["Impact"]

                # =================================================
                # REMEDIATION RECOMMENDATION
                # =================================================

                ws.cell(
                    row=row_num,
                    column=headers["Remediation recommendation"]
                ).value = vuln_data["Recommendation"]

                updated_count += 1

                print(f"[+] Updated: {original_title}")

        # =================================================
        # SAVE FILE
        # =================================================

        wb.save(output_file)

        print(f"[+] Total updated: {updated_count}")
        print(f"[+] Saved: {output_file}")

    except Exception as e:

        print(f"[ERROR] {file_name}")
        print(str(e))

print("\n=================================================")
print("[+] All files processed successfully")